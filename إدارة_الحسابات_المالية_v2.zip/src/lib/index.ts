// ============================================================
// Types & Interfaces
// ============================================================

export interface Transaction {
  id: string;
  date: string;           // ISO date string
  type: 'استلام' | 'تسليم';
  amount: number;
  person: string;         // من استلم / من سُلِّم إليه
  notes: string;
  runningBalance?: number;
}

export interface Client {
  id: string;
  name: string;
  createdAt: string;
  transactions: Transaction[];
}

export interface ClientSummary {
  totalIn: number;    // ما له (لنا)
  totalOut: number;   // ما علينا
  balance: number;    // الرصيد الصافي
  status: 'له' | 'علينا' | 'متعادل';
  lastTransaction: string | null;
}

// ============================================================
// Route Paths
// ============================================================
export const ROUTE_PATHS = {
  HOME: '/',
  ADD_CLIENT: '/add-client',
  CLIENT: '/client/:id',
} as const;

// ============================================================
// Helper functions
// ============================================================
export function getClientSummary(client: Client): ClientSummary {
  const totalIn  = client.transactions
    .filter(t => t.type === 'استلام')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalOut = client.transactions
    .filter(t => t.type === 'تسليم')
    .reduce((sum, t) => sum + t.amount, 0);
  const balance  = totalIn - totalOut;

  const status: 'له' | 'علينا' | 'متعادل' =
    balance > 0 ? 'له' : balance < 0 ? 'علينا' : 'متعادل';

  const lastTxDate =
    client.transactions.length > 0
      ? client.transactions[client.transactions.length - 1].date
      : null;

  return { totalIn, totalOut, balance, status, lastTransaction: lastTxDate };
}

export function computeRunningBalances(transactions: Transaction[]): Transaction[] {
  let running = 0;
  return transactions.map(t => {
    running += t.type === 'استلام' ? t.amount : -t.amount;
    return { ...t, runningBalance: running };
  });
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('ar-EG', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(amount));
}

export function formatDate(dateStr: string): string {
  try {
    return new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric', month: 'long', day: 'numeric',
    }).format(new Date(dateStr));
  } catch {
    return dateStr;
  }
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
