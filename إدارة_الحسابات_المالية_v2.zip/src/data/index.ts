import { Client, generateId } from '@/lib/index';

const STORAGE_KEY = 'client_finance_data';

// ============================================================
// بيانات تجريبية افتراضية
// ============================================================
function getDefaultData(): Client[] {
  const today = new Date();
  const d = (days: number) => {
    const dt = new Date(today);
    dt.setDate(dt.getDate() - days);
    return dt.toISOString().split('T')[0];
  };

  return [
    {
      id: generateId(),
      name: 'أحمد محمد',
      createdAt: d(60),
      transactions: [
        { id: generateId(), date: d(60), type: 'استلام', amount: 10000, person: 'محمد سعيد',    notes: 'دفعة أولى - بداية التعامل' },
        { id: generateId(), date: d(45), type: 'استلام', amount: 5000,  person: 'أحمد رضا',     notes: 'دفعة ثانية' },
        { id: generateId(), date: d(30), type: 'تسليم',  amount: 3000,  person: 'خالد أمين',    notes: 'استرداد جزئي بطلب العميل' },
        { id: generateId(), date: d(15), type: 'استلام', amount: 3000,  person: 'محمد سعيد',    notes: 'دفعة ثالثة' },
      ],
    },
    {
      id: generateId(),
      name: 'سارة علي',
      createdAt: d(90),
      transactions: [
        { id: generateId(), date: d(90), type: 'استلام', amount: 8000,  person: 'سامي حسن',     notes: 'بداية التعامل' },
        { id: generateId(), date: d(60), type: 'تسليم',  amount: 12000, person: 'رانيا مصطفى',  notes: 'سداد كامل + فائدة' },
      ],
    },
    {
      id: generateId(),
      name: 'شركة النور للتجارة',
      createdAt: d(120),
      transactions: [
        { id: generateId(), date: d(120), type: 'استلام', amount: 20000, person: 'مدير المبيعات',  notes: 'عقد الربع الأول' },
        { id: generateId(), date: d(90),  type: 'استلام', amount: 15000, person: 'محاسب الشركة',   notes: 'دفعة الربع الثاني' },
        { id: generateId(), date: d(60),  type: 'استلام', amount: 15000, person: 'مدير المبيعات',  notes: 'دفعة الربع الثالث' },
        { id: generateId(), date: d(30),  type: 'تسليم',  amount: 10000, person: 'أمين الصندوق',   notes: 'دفعة مرتجعة (1)' },
        { id: generateId(), date: d(10),  type: 'تسليم',  amount: 10000, person: 'أمين الصندوق',   notes: 'دفعة مرتجعة (2)' },
      ],
    },
    {
      id: generateId(),
      name: 'خالد إبراهيم',
      createdAt: d(45),
      transactions: [
        { id: generateId(), date: d(45), type: 'استلام', amount: 3000, person: 'عمر حسين',  notes: 'تسوية حساب' },
        { id: generateId(), date: d(20), type: 'تسليم',  amount: 3000, person: 'عمر حسين',  notes: 'رد كامل المبلغ' },
      ],
    },
    {
      id: generateId(),
      name: 'مؤسسة الأمل',
      createdAt: d(100),
      transactions: [
        { id: generateId(), date: d(100), type: 'استلام', amount: 15000, person: 'مدير المؤسسة',      notes: 'دفعة أولى' },
        { id: generateId(), date: d(70),  type: 'استلام', amount: 10000, person: 'أمين مال المؤسسة',  notes: 'دفعة ثانية' },
        { id: generateId(), date: d(40),  type: 'تسليم',  amount: 8000,  person: 'مدير المؤسسة',      notes: 'استرداد جزئي' },
      ],
    },
  ];
}

// ============================================================
// Store API  (localStorage)
// ============================================================
export function loadClients(): Client[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const defaults = getDefaultData();
      saveClients(defaults);
      return defaults;
    }
    return JSON.parse(raw) as Client[];
  } catch {
    return getDefaultData();
  }
}

export function saveClients(clients: Client[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
}

export function addClient(name: string): Client {
  const clients = loadClients();
  const newClient: Client = {
    id: generateId(),
    name: name.trim(),
    createdAt: new Date().toISOString().split('T')[0],
    transactions: [],
  };
  saveClients([...clients, newClient]);
  return newClient;
}

export function deleteClient(id: string): void {
  const clients = loadClients().filter(c => c.id !== id);
  saveClients(clients);
}

export function addTransaction(
  clientId: string,
  tx: Omit<import('@/lib/index').Transaction, 'id'>
): void {
  const clients = loadClients();
  const idx = clients.findIndex(c => c.id === clientId);
  if (idx === -1) return;
  const newTx = { ...tx, id: generateId() };
  clients[idx].transactions.push(newTx);
  saveClients(clients);
}

export function deleteTransaction(clientId: string, txId: string): void {
  const clients = loadClients();
  const idx = clients.findIndex(c => c.id === clientId);
  if (idx === -1) return;
  clients[idx].transactions = clients[idx].transactions.filter(t => t.id !== txId);
  saveClients(clients);
}

export function clientNameExists(name: string, excludeId?: string): boolean {
  return loadClients().some(
    c => c.name.trim() === name.trim() && c.id !== excludeId
  );
}
