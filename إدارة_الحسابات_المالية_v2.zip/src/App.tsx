import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { ROUTE_PATHS } from '@/lib/index';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import AddClient from '@/pages/AddClient';
import ClientDetail from '@/pages/ClientDetail';

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path={ROUTE_PATHS.HOME}       element={<Dashboard />} />
          <Route path={ROUTE_PATHS.ADD_CLIENT} element={<AddClient />} />
          <Route path={ROUTE_PATHS.CLIENT}     element={<ClientDetail />} />
        </Routes>
      </Layout>
    </Router>
  );
}
