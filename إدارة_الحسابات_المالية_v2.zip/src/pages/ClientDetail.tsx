import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, ArrowDownCircle, ArrowUpCircle, Scale,
  PlusCircle, Trash2, AlertCircle, CheckCircle2, TrendingUp,
  TrendingDown, CalendarDays, User, StickyNote, X
} from 'lucide-react';
import { useClients } from '@/hooks/useClients';
import {
  getClientSummary, computeRunningBalances,
  formatCurrency, formatDate, ROUTE_PATHS
} from '@/lib/index';
import { StatCard, StatusBadge, BalanceDisplay, EmptyState } from '@/components/Stats';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Transaction } from '@/lib/index';

// ============================================================
// Add Transaction Modal
// ============================================================
interface AddTxModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (tx: Omit<Transaction, 'id'>) => void;
}

function AddTxModal({ open, onClose, onSave }: AddTxModalProps) {
  const today = new Date().toISOString().split('T')[0];
  const [form, setForm] = useState({
    date: today, type: 'استلام' as 'استلام' | 'تسليم',
    amount: '', person: '', notes: '',
  });
  const [error, setError] = useState('');

  const handleSave = () => {
    setError('');
    if (!form.amount || isNaN(Number(form.amount)) || Number(form.amount) <= 0) {
      setError('الرجاء إدخال مبلغ صحيح أكبر من صفر'); return;
    }
    if (!form.person.trim()) { setError('الرجاء إدخال اسم المسؤول'); return; }
    onSave({
      date: form.date,
      type: form.type,
      amount: Number(form.amount),
      person: form.person.trim(),
      notes: form.notes.trim(),
    });
    setForm({ date: today, type: 'استلام', amount: '', person: '', notes: '' });
    setError('');
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="absolute inset-0 bg-black/60"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-md shadow-xl z-10"
        dir="rtl"
      >
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-lg text-foreground">إضافة معاملة جديدة</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-4">
          {/* Type */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">نوع المعاملة</label>
            <div className="grid grid-cols-2 gap-2">
              {(['استلام', 'تسليم'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setForm(f => ({ ...f, type: t }))}
                  className={`py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 border transition-all ${
                    form.type === t
                      ? t === 'استلام'
                        ? 'bg-success text-white border-success'
                        : 'bg-destructive text-white border-destructive'
                      : 'bg-muted text-muted-foreground border-border hover:border-primary/40'
                  }`}
                >
                  {t === 'استلام' ? <ArrowDownCircle size={16} /> : <ArrowUpCircle size={16} />}
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Amount */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">المبلغ (ج.م) <span className="text-destructive">*</span></label>
            <input
              type="number" min="0" step="0.01"
              value={form.amount}
              onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
              placeholder="0.00"
              className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 font-mono placeholder:text-muted-foreground"
            />
          </div>

          {/* Date */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">التاريخ</label>
            <input
              type="date"
              value={form.date}
              onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
              className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>

          {/* Person */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">المسؤول <span className="text-destructive">*</span></label>
            <input
              value={form.person}
              onChange={e => setForm(f => ({ ...f, person: e.target.value }))}
              placeholder="اسم من استلم / سلّم المبلغ"
              className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">ملاحظات</label>
            <textarea
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              placeholder="أي ملاحظات إضافية..."
              rows={2}
              className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 resize-none placeholder:text-muted-foreground"
            />
          </div>

          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/30 rounded-xl text-destructive text-sm"
              >
                <AlertCircle size={15} /> {error}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex gap-3 pt-1">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-muted text-foreground text-sm font-medium hover:bg-muted/70 transition-colors"
            >
              إلغاء
            </button>
            <button
              onClick={handleSave}
              className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle2 size={16} /> حفظ المعاملة
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// ============================================================
// ClientDetail Page
// ============================================================
export default function ClientDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getClient, addTransaction, deleteTransaction } = useClients();
  const [showModal, setShowModal] = useState(false);

  const client = id ? getClient(id) : undefined;

  if (!client) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <AlertCircle size={48} className="text-destructive" />
        <p className="text-xl font-bold">العميل غير موجود</p>
        <button
          onClick={() => navigate(ROUTE_PATHS.HOME)}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm"
        >
          العودة للبيان
        </button>
      </div>
    );
  }

  const summary = getClientSummary(client);
  const txWithBalance = computeRunningBalances(client.transactions);

  const handleAddTx = (tx: Omit<Transaction, 'id'>) => {
    addTransaction(client.id, tx);
  };

  return (
    <div className="space-y-6">
      {/* Breadcrumb + Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate(ROUTE_PATHS.HOME)}
          className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm"
        >
          <ArrowRight size={16} />
          البيان الرئيسي
        </button>
        <span className="text-muted-foreground">/</span>
        <span className="font-semibold text-foreground">{client.name}</span>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
            {client.name[0]}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{client.name}</h1>
            <div className="flex items-center gap-2 mt-1">
              <StatusBadge status={summary.status} />
              <span className="text-xs text-muted-foreground">منذ {formatDate(client.createdAt)}</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-semibold text-sm hover:opacity-90 active:scale-[0.98] transition-all"
        >
          <PlusCircle size={18} />
          إضافة معاملة
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="إجمالي له (لنا)"
          value={summary.totalIn}
          icon={<TrendingUp size={18} className="text-success" />}
          variant="success"
        />
        <StatCard
          label="إجمالي علينا"
          value={summary.totalOut}
          icon={<TrendingDown size={18} className="text-destructive" />}
          variant="danger"
        />
        <StatCard
          label="الرصيد الصافي"
          value={Math.abs(summary.balance)}
          suffix={summary.balance >= 0 ? 'ج.م له علينا' : 'ج.م علينا'}
          icon={<Scale size={18} className="text-warning" />}
          variant={summary.balance > 0 ? 'success' : summary.balance < 0 ? 'danger' : 'neutral'}
        />
        <StatCard
          label="عدد المعاملات"
          value={client.transactions.length}
          suffix="معاملة"
          icon={<CalendarDays size={18} className="text-primary" />}
          variant="default"
        />
      </div>

      {/* Transactions Table */}
      <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-bold text-foreground">سجل المعاملات</h2>
          <span className="text-xs text-muted-foreground">{client.transactions.length} معاملة</span>
        </div>

        {txWithBalance.length === 0 ? (
          <EmptyState
            icon={<CalendarDays size={36} />}
            title="لا توجد معاملات بعد"
            description="اضغط على إضافة معاملة لتسجيل أول عملية"
            action={
              <button
                onClick={() => setShowModal(true)}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium"
              >
                إضافة معاملة
              </button>
            }
          />
        ) : (
          <>
            {/* Desktop */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50 border-b border-border">
                    <th className="text-right px-4 py-3 text-muted-foreground font-semibold">#</th>
                    <th className="text-right px-4 py-3 text-muted-foreground font-semibold">
                      <div className="flex items-center gap-1"><CalendarDays size={13} /> التاريخ</div>
                    </th>
                    <th className="text-right px-4 py-3 text-muted-foreground font-semibold">النوع</th>
                    <th className="text-right px-4 py-3 text-muted-foreground font-semibold">
                      <div className="flex items-center gap-1"><User size={13} /> المسؤول</div>
                    </th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-semibold font-mono">المبلغ</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-semibold font-mono">الرصيد التراكمي</th>
                    <th className="text-right px-4 py-3 text-muted-foreground font-semibold">
                      <div className="flex items-center gap-1"><StickyNote size={13} /> ملاحظات</div>
                    </th>
                    <th className="text-center px-4 py-3 text-muted-foreground font-semibold">حذف</th>
                  </tr>
                </thead>
                <tbody>
                  {txWithBalance.map((tx, idx) => (
                    <motion.tr
                      key={tx.id}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.03 }}
                      className={`border-b border-border/60 transition-colors ${
                        tx.type === 'استلام' ? 'hover:bg-success/5' : 'hover:bg-destructive/5'
                      }`}
                    >
                      <td className="px-4 py-3 text-muted-foreground text-xs">{idx + 1}</td>
                      <td className="px-4 py-3 text-sm">{formatDate(tx.date)}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          tx.type === 'استلام'
                            ? 'bg-success/15 text-success border border-success/30'
                            : 'bg-destructive/15 text-destructive border border-destructive/30'
                        }`}>
                          {tx.type === 'استلام' ? <ArrowDownCircle size={11} /> : <ArrowUpCircle size={11} />}
                          {tx.type}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium">{tx.person}</td>
                      <td className="px-4 py-3 font-mono text-left">
                        <span className={tx.type === 'استلام' ? 'text-success font-semibold' : 'text-destructive font-semibold'}>
                          {tx.type === 'استلام' ? '+' : '-'}{formatCurrency(tx.amount)} ج.م
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-left">
                        <BalanceDisplay balance={tx.runningBalance ?? 0} />
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs max-w-[180px] truncate">
                        {tx.notes || '—'}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button className="p-1.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors">
                              <Trash2 size={14} />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent dir="rtl">
                            <AlertDialogHeader>
                              <AlertDialogTitle>حذف المعاملة</AlertDialogTitle>
                              <AlertDialogDescription>
                                هل تريد حذف هذه المعاملة؟ ({tx.type} {formatCurrency(tx.amount)} ج.م بتاريخ {formatDate(tx.date)})
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter className="flex-row-reverse gap-2">
                              <AlertDialogCancel>إلغاء</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteTransaction(client.id, tx.id)}
                                className="bg-destructive text-destructive-foreground"
                              >
                                حذف
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden divide-y divide-border">
              {txWithBalance.map((tx, idx) => (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.03 }}
                  className={`p-4 ${tx.type === 'استلام' ? 'bg-success/5' : 'bg-destructive/5'}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${
                        tx.type === 'استلام' ? 'bg-success/20 text-success' : 'bg-destructive/20 text-destructive'
                      }`}>
                        {tx.type === 'استلام' ? <ArrowDownCircle size={10} /> : <ArrowUpCircle size={10} />}
                        {tx.type}
                      </span>
                      <span className="text-xs text-muted-foreground">{formatDate(tx.date)}</span>
                    </div>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button className="p-1 rounded text-destructive/60 hover:text-destructive">
                          <Trash2 size={13} />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent dir="rtl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>حذف المعاملة</AlertDialogTitle>
                          <AlertDialogDescription>تأكيد حذف هذه المعاملة؟</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter className="flex-row-reverse gap-2">
                          <AlertDialogCancel>إلغاء</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteTransaction(client.id, tx.id)} className="bg-destructive text-destructive-foreground">حذف</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">{tx.person}</p>
                      {tx.notes && <p className="text-xs text-muted-foreground mt-0.5">{tx.notes}</p>}
                    </div>
                    <div className="text-left">
                      <p className={`font-mono font-bold ${tx.type === 'استلام' ? 'text-success' : 'text-destructive'}`}>
                        {tx.type === 'استلام' ? '+' : '-'}{formatCurrency(tx.amount)} ج.م
                      </p>
                      <p className="text-xs text-muted-foreground text-left">
                        رصيد: <BalanceDisplay balance={tx.runningBalance ?? 0} className="text-xs" />
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Add Transaction Modal */}
      <AddTxModal
        open={showModal}
        onClose={() => setShowModal(false)}
        onSave={handleAddTx}
      />
    </div>
  );
}
