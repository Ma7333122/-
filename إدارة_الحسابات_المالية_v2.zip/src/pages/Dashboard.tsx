import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Search, ArrowUpCircle, ArrowDownCircle, Scale,
  Eye, Trash2, TrendingUp, TrendingDown, Users, FileText,
  Download, Upload, RefreshCw
} from 'lucide-react';
import { useClients } from '@/hooks/useClients';
import { getClientSummary, formatCurrency, formatDate, ROUTE_PATHS } from '@/lib/index';
import { StatCard, StatusBadge, BalanceDisplay, EmptyState } from '@/components/Stats';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function Dashboard() {
  const navigate = useNavigate();
  const { clients, deleteClient, importData } = useClients();
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'balance' | 'date'>('name');

  const handleExport = () => {
    const data = JSON.stringify(clients, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `حسابات_العملاء_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (Array.isArray(data)) {
          importData(data);
          alert('تم استيراد البيانات بنجاح!');
        } else {
          alert('تنسيق الملف غير صحيح');
        }
      } catch (err) {
        alert('حدث خطأ أثناء قراءة الملف');
      }
    };
    reader.readAsText(file);
  };

  // --------- Totals ---------
  const totals = useMemo(() => {
    const totalIn  = clients.reduce((s, c) => s + getClientSummary(c).totalIn,  0);
    const totalOut = clients.reduce((s, c) => s + getClientSummary(c).totalOut, 0);
    const balance  = totalIn - totalOut;
    return { totalIn, totalOut, balance };
  }, [clients]);

  // --------- Filtered + sorted clients ---------
  const displayClients = useMemo(() => {
    let list = clients.filter(c =>
      c.name.toLowerCase().includes(search.toLowerCase())
    );
    if (sortBy === 'name')    list = [...list].sort((a, b) => a.name.localeCompare(b.name, 'ar'));
    if (sortBy === 'balance') list = [...list].sort((a, b) => getClientSummary(b).balance - getClientSummary(a).balance);
    if (sortBy === 'date')    list = [...list].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return list;
  }, [clients, search, sortBy]);

  return (
    <div className="space-y-6">
      {/* Page title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">البيان المالي الرئيسي</h1>
          <p className="text-muted-foreground text-sm mt-1">ملخص شامل لجميع حسابات العملاء</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-3 py-2 bg-muted hover:bg-muted/80 text-foreground rounded-xl text-xs font-medium transition-colors"
            title="تصدير نسخة احتياطية (Download Data)"
          >
            <Download size={14} />
            <span className="hidden sm:inline">تصدير (Backup)</span>
          </button>
          <label className="flex items-center gap-2 px-3 py-2 bg-muted hover:bg-muted/80 text-foreground rounded-xl text-xs font-medium transition-colors cursor-pointer">
            <Upload size={14} />
            <span className="hidden sm:inline">استيراد (Import)</span>
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>
        </div>
      </div>

      {/* ===== Stats Cards ===== */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="عدد العملاء"
          value={clients.length}
          suffix="عميل"
          icon={<Users size={18} className="text-primary" />}
          variant="default"
        />
        <StatCard
          label="إجمالي له (لنا)"
          value={totals.totalIn}
          icon={<TrendingUp size={18} className="text-success" />}
          variant="success"
        />
        <StatCard
          label="إجمالي علينا"
          value={totals.totalOut}
          icon={<TrendingDown size={18} className="text-destructive" />}
          variant="danger"
        />
        <StatCard
          label="الرصيد الصافي"
          value={Math.abs(totals.balance)}
          suffix={totals.balance >= 0 ? 'ج.م ✅ لنا' : 'ج.م 🔴 علينا'}
          icon={<Scale size={18} className="text-warning" />}
          variant={totals.balance > 0 ? 'success' : totals.balance < 0 ? 'danger' : 'neutral'}
        />
      </div>

      {/* ===== Summary Banner ===== */}
      <div className={`rounded-2xl p-4 border flex flex-col sm:flex-row items-start sm:items-center gap-3 ${
        totals.balance > 0 ? 'bg-success/5 border-success/30' :
        totals.balance < 0 ? 'bg-destructive/5 border-destructive/30' : 'bg-muted border-border'
      }`}>
        <FileText size={20} className={totals.balance >= 0 ? 'text-success' : 'text-destructive'} />
        <div>
          <span className="font-semibold text-sm text-foreground">الخلاصة الإجمالية: </span>
          {totals.balance > 0 && (
            <span className="text-sm text-success">
              لدينا إجمالي مستحق <strong>{formatCurrency(totals.balance)} ج.م</strong> من العملاء ✅
            </span>
          )}
          {totals.balance < 0 && (
            <span className="text-sm text-destructive">
              علينا إجمالي مستحق <strong>{formatCurrency(totals.balance)} ج.م</strong> للعملاء 🔴
            </span>
          )}
          {totals.balance === 0 && (
            <span className="text-sm text-muted-foreground">الحسابات متعادلة تماماً ⚖️</span>
          )}
        </div>
      </div>

      {/* ===== Search & Sort ===== */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ابحث عن عميل..."
            className="w-full bg-card border border-border rounded-xl pr-9 pl-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground whitespace-nowrap">ترتيب حسب:</span>
          {(['name', 'balance', 'date'] as const).map(opt => (
            <button
              key={opt}
              onClick={() => setSortBy(opt)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                sortBy === opt ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/70'
              }`}
            >
              {opt === 'name' ? 'الاسم' : opt === 'balance' ? 'الرصيد' : 'الأحدث'}
            </button>
          ))}
        </div>
      </div>

      {/* ===== Clients Table ===== */}
      {displayClients.length === 0 ? (
        <EmptyState
          icon={<Users size={40} />}
          title={search ? 'لا يوجد عميل بهذا الاسم' : 'لا يوجد عملاء بعد'}
          description={search ? 'جرب بحثاً مختلفاً' : 'ابدأ بإضافة عميلك الأول'}
          action={
            !search && (
              <button
                onClick={() => navigate(ROUTE_PATHS.ADD_CLIENT)}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90"
              >
                إضافة عميل
              </button>
            )
          }
        />
      ) : (
        <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm">
          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 border-b border-border">
                  <th className="text-right px-4 py-3 text-muted-foreground font-semibold w-10">#</th>
                  <th className="text-right px-4 py-3 text-muted-foreground font-semibold">اسم العميل</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-semibold font-mono">له (لنا)</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-semibold font-mono">علينا</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-semibold font-mono">الرصيد الصافي</th>
                  <th className="text-right px-4 py-3 text-muted-foreground font-semibold">الحالة</th>
                  <th className="text-right px-4 py-3 text-muted-foreground font-semibold">آخر معاملة</th>
                  <th className="text-center px-4 py-3 text-muted-foreground font-semibold">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {displayClients.map((client, idx) => {
                  const s = getClientSummary(client);
                  return (
                    <motion.tr
                      key={client.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.04, type: 'spring', stiffness: 260, damping: 28 }}
                      className="border-b border-border/60 hover:bg-muted/30 transition-colors"
                    >
                      <td className="px-4 py-3 text-muted-foreground">{idx + 1}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => navigate(ROUTE_PATHS.CLIENT.replace(':id', client.id))}
                          className="font-semibold text-primary hover:underline flex items-center gap-1.5"
                        >
                          {client.name}
                          <Eye size={13} className="opacity-60" />
                        </button>
                        <span className="text-xs text-muted-foreground">{client.transactions.length} معاملة</span>
                      </td>
                      <td className="px-4 py-3 font-mono text-success text-left">
                        <div className="flex items-center gap-1">
                          <ArrowDownCircle size={13} className="text-success" />
                          {formatCurrency(s.totalIn)}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-destructive text-left">
                        <div className="flex items-center gap-1">
                          <ArrowUpCircle size={13} className="text-destructive" />
                          {formatCurrency(s.totalOut)}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-left">
                        <BalanceDisplay balance={s.balance} />
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={s.status} size="sm" />
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs">
                        {s.lastTransaction ? formatDate(s.lastTransaction) : '—'}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => navigate(ROUTE_PATHS.CLIENT.replace(':id', client.id))}
                            className="p-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                            title="عرض التفاصيل"
                          >
                            <Eye size={15} />
                          </button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <button
                                className="p-1.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
                                title="حذف العميل"
                              >
                                <Trash2 size={15} />
                              </button>
                            </AlertDialogTrigger>
                            <AlertDialogContent dir="rtl">
                              <AlertDialogHeader>
                                <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
                                <AlertDialogDescription>
                                  هل أنت متأكد من حذف العميل <strong>{client.name}</strong>؟
                                  سيتم حذف جميع معاملاته ({client.transactions.length} معاملة) نهائياً.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter className="flex-row-reverse gap-2">
                                <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteClient(client.id)}
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                >
                                  نعم، احذف
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
              {/* Totals row */}
              <tfoot>
                <tr className="bg-warning/5 border-t-2 border-warning/30">
                  <td colSpan={2} className="px-4 py-3 font-bold text-foreground">
                    الإجمالي الكلي ({displayClients.length} عميل)
                  </td>
                  <td className="px-4 py-3 font-bold font-mono text-success text-left">
                    {formatCurrency(displayClients.reduce((s, c) => s + getClientSummary(c).totalIn, 0))} ج.م
                  </td>
                  <td className="px-4 py-3 font-bold font-mono text-destructive text-left">
                    {formatCurrency(displayClients.reduce((s, c) => s + getClientSummary(c).totalOut, 0))} ج.م
                  </td>
                  <td className="px-4 py-3 text-left">
                    <BalanceDisplay
                      balance={displayClients.reduce((s, c) => s + getClientSummary(c).balance, 0)}
                      className="font-bold"
                    />
                  </td>
                  <td colSpan={3} />
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden divide-y divide-border">
            {displayClients.map((client, idx) => {
              const s = getClientSummary(client);
              return (
                <motion.div
                  key={client.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  className="p-4 hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <button
                      onClick={() => navigate(ROUTE_PATHS.CLIENT.replace(':id', client.id))}
                      className="font-semibold text-primary hover:underline"
                    >
                      {client.name}
                    </button>
                    <StatusBadge status={s.status} size="sm" />
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="bg-success/10 rounded-lg p-2 text-center">
                      <p className="text-muted-foreground">له</p>
                      <p className="font-mono text-success font-semibold">{formatCurrency(s.totalIn)}</p>
                    </div>
                    <div className="bg-destructive/10 rounded-lg p-2 text-center">
                      <p className="text-muted-foreground">علينا</p>
                      <p className="font-mono text-destructive font-semibold">{formatCurrency(s.totalOut)}</p>
                    </div>
                    <div className="bg-muted rounded-lg p-2 text-center">
                      <p className="text-muted-foreground">الصافي</p>
                      <BalanceDisplay balance={s.balance} className="text-xs" />
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => navigate(ROUTE_PATHS.CLIENT.replace(':id', client.id))}
                      className="flex-1 py-1.5 bg-primary/10 text-primary rounded-lg text-xs font-medium flex items-center justify-center gap-1"
                    >
                      <Eye size={13} /> عرض
                    </button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button className="px-3 py-1.5 bg-destructive/10 text-destructive rounded-lg text-xs">
                          <Trash2 size={13} />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent dir="rtl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
                          <AlertDialogDescription>
                            هل تريد حذف <strong>{client.name}</strong> وجميع معاملاته؟
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter className="flex-row-reverse gap-2">
                          <AlertDialogCancel>إلغاء</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteClient(client.id)} className="bg-destructive text-destructive-foreground">
                            حذف
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}