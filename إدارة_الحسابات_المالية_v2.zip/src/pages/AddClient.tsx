import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { UserPlus, Search, CheckCircle2, AlertCircle, Users, Eye, ArrowLeft } from 'lucide-react';
import { useClients } from '@/hooks/useClients';
import { ROUTE_PATHS, formatDate } from '@/lib/index';
import { StatusBadge } from '@/components/Stats';
import { getClientSummary } from '@/lib/index';

export default function AddClient() {
  const navigate = useNavigate();
  const { clients, addClient } = useClients();

  // --- Add form state ---
  const [newName, setNewName]         = useState('');
  const [addError, setAddError]       = useState('');
  const [addSuccess, setAddSuccess]   = useState('');
  const [adding, setAdding]           = useState(false);

  // --- Search state ---
  const [query, setQuery]             = useState('');

  const handleAdd = () => {
    setAddError('');
    setAddSuccess('');
    if (!newName.trim()) { setAddError('الرجاء كتابة اسم العميل'); return; }
    setAdding(true);
    const result = addClient(newName);
    setAdding(false);
    if (!result.ok) { setAddError(result.error ?? 'حدث خطأ'); return; }
    setAddSuccess(`تم إضافة العميل "${newName.trim()}" بنجاح! جاري الانتقال...`);
    const id = result.client!.id;
    setNewName('');
    setTimeout(() => navigate(ROUTE_PATHS.CLIENT.replace(':id', id)), 1200);
  };

  // --- Filtered client list ---
  const filteredClients = useMemo(() => {
    if (!query.trim()) return clients;
    return clients.filter(c => c.name.toLowerCase().includes(query.toLowerCase()));
  }, [clients, query]);

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">إضافة / بحث عميل</h1>
        <p className="text-muted-foreground text-sm mt-1">أضف عميلاً جديداً أو ابحث عن عميل موجود</p>
      </div>

      {/* ===== Add Client Card ===== */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-2xl border border-border p-6 shadow-sm"
      >
        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 rounded-xl bg-primary/10">
            <UserPlus size={20} className="text-primary" />
          </div>
          <div>
            <h2 className="font-bold text-foreground">إضافة عميل جديد</h2>
            <p className="text-xs text-muted-foreground">سيتم فتح صفحة العميل تلقائياً بعد الإضافة</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">اسم العميل <span className="text-destructive">*</span></label>
            <input
              value={newName}
              onChange={e => { setNewName(e.target.value); setAddError(''); setAddSuccess(''); }}
              onKeyDown={e => e.key === 'Enter' && handleAdd()}
              placeholder="أدخل اسم العميل هنا..."
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
            />
          </div>

          <AnimatePresence>
            {addError && (
              <motion.div
                initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/30 rounded-xl text-destructive text-sm"
              >
                <AlertCircle size={16} />
                {addError}
              </motion.div>
            )}
            {addSuccess && (
              <motion.div
                initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                className="flex items-center gap-2 p-3 bg-success/10 border border-success/30 rounded-xl text-success text-sm"
              >
                <CheckCircle2 size={16} />
                {addSuccess}
              </motion.div>
            )}
          </AnimatePresence>

          <button
            onClick={handleAdd}
            disabled={adding || !!addSuccess}
            className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-semibold text-sm hover:opacity-90 active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <UserPlus size={18} />
            {adding ? 'جاري الإضافة...' : 'إضافة العميل الآن'}
          </button>
        </div>
      </motion.div>

      {/* ===== Search & Client List ===== */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-card rounded-2xl border border-border p-6 shadow-sm"
      >
        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 rounded-xl bg-accent/10">
            <Search size={20} className="text-accent-foreground" />
          </div>
          <div>
            <h2 className="font-bold text-foreground">البحث عن عميل</h2>
            <p className="text-xs text-muted-foreground">{clients.length} عميل مسجل</p>
          </div>
        </div>

        <div className="relative mb-4">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="ابحث بالاسم..."
            className="w-full bg-background border border-border rounded-xl pr-9 pl-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
          />
        </div>

        {filteredClients.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Users size={32} className="mx-auto mb-2 opacity-40" />
            <p className="text-sm">{query ? 'لا يوجد عميل بهذا الاسم' : 'لا يوجد عملاء مسجلون بعد'}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredClients.map((client, idx) => {
              const s = getClientSummary(client);
              return (
                <motion.button
                  key={client.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.03 }}
                  onClick={() => navigate(ROUTE_PATHS.CLIENT.replace(':id', client.id))}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors text-right border border-transparent hover:border-border group"
                >
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-primary font-bold text-sm">
                    {client.name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm truncate">{client.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {client.transactions.length} معاملة · آخر تعامل: {s.lastTransaction ? formatDate(s.lastTransaction) : '—'}
                    </p>
                  </div>
                  <div className="shrink-0 flex items-center gap-2">
                    <StatusBadge status={s.status} size="sm" />
                    <ArrowLeft size={14} className="text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </motion.button>
              );
            })}
          </div>
        )}
      </motion.div>
    </div>
  );
}
