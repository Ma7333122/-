import { ReactNode, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, UserPlus, Search, Menu, X,
  TrendingUp, Users, ChevronRight, Banknote
} from 'lucide-react';
import { ROUTE_PATHS } from '@/lib/index';

interface LayoutProps {
  children: ReactNode;
}

const navItems = [
  { to: ROUTE_PATHS.HOME,       icon: LayoutDashboard, label: 'البيان الرئيسي' },
  { to: ROUTE_PATHS.ADD_CLIENT, icon: UserPlus,         label: 'إضافة / بحث عميل' },
];

export default function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground flex" dir="rtl">
      {/* ===== Sidebar Desktop ===== */}
      <aside className="hidden lg:flex flex-col w-64 bg-card border-l border-border shrink-0 fixed right-0 top-0 h-full z-40">
        <SidebarContent onNavigate={() => setSidebarOpen(false)} />
      </aside>

      {/* ===== Mobile Overlay ===== */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              key="overlay"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              key="sidebar"
              initial={{ x: 260 }} animate={{ x: 0 }} exit={{ x: 260 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed right-0 top-0 h-full w-64 bg-card border-l border-border z-50 lg:hidden flex flex-col"
            >
              <SidebarContent onNavigate={() => setSidebarOpen(false)} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* ===== Main Content ===== */}
      <div className="flex-1 lg:mr-64 flex flex-col min-h-screen">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-card/80 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors"
          >
            <Menu size={20} />
          </button>

          <button
            onClick={() => navigate(ROUTE_PATHS.HOME)}
            className="flex items-center gap-2 text-primary font-bold text-lg"
          >
            <Banknote size={22} className="text-primary" />
            <span>نظام إدارة الحسابات</span>
          </button>

          <div className="flex-1" />

          <button
            onClick={() => navigate(ROUTE_PATHS.ADD_CLIENT)}
            className="flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <UserPlus size={16} />
            <span className="hidden sm:inline">إضافة عميل</span>
          </button>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 md:p-6">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 28 }}
          >
            {children}
          </motion.div>
        </main>

        <footer className="text-center text-xs text-muted-foreground py-3 border-t border-border">
          نظام إدارة الحسابات المالية © {new Date().getFullYear()}
        </footer>
      </div>
    </div>
  );
}

function SidebarContent({ onNavigate }: { onNavigate: () => void }) {
  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
            <Banknote size={22} className="text-primary-foreground" />
          </div>
          <div>
            <p className="font-bold text-foreground text-sm leading-tight">نظام إدارة</p>
            <p className="font-bold text-primary text-sm leading-tight">الحسابات المالية</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <p className="text-xs font-semibold text-muted-foreground px-3 pt-2 pb-1 uppercase tracking-wider">القائمة الرئيسية</p>
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === ROUTE_PATHS.HOME}
            onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <item.icon size={18} />
                <span className="flex-1">{item.label}</span>
                {isActive && <ChevronRight size={14} className="opacity-60" />}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <TrendingUp size={14} className="text-success" />
          <span>البيانات محفوظة محلياً</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
          <Users size={14} />
          <span>جاهز للاستخدام</span>
        </div>
      </div>
    </div>
  );
}
