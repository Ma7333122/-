import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { formatCurrency } from '@/lib/index';

// ============================================================
// StatCard
// ============================================================
interface StatCardProps {
  label: string;
  value: number;
  icon: ReactNode;
  variant?: 'default' | 'success' | 'danger' | 'warning' | 'neutral';
  suffix?: string;
}

const variantStyles: Record<string, string> = {
  default:  'border-border',
  success:  'border-success/30 bg-success/5',
  danger:   'border-destructive/30 bg-destructive/5',
  warning:  'border-warning/30 bg-warning/5',
  neutral:  'border-border bg-muted/30',
};
const valueColors: Record<string, string> = {
  default: 'text-foreground',
  success: 'text-success',
  danger:  'text-destructive',
  warning: 'text-warning',
  neutral: 'text-muted-foreground',
};

export function StatCard({ label, value, icon, variant = 'default', suffix = 'ج.م' }: StatCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className={`rounded-2xl border p-5 bg-card flex flex-col gap-3 shadow-sm ${variantStyles[variant]}`}
    >
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground font-medium">{label}</span>
        <div className={`p-2 rounded-xl ${variant === 'success' ? 'bg-success/10' : variant === 'danger' ? 'bg-destructive/10' : variant === 'warning' ? 'bg-warning/10' : 'bg-muted'}`}>
          {icon}
        </div>
      </div>
      <div>
        <span className={`text-2xl font-bold font-mono ${valueColors[variant]}`}>
          {formatCurrency(value)}
        </span>
        <span className="text-xs text-muted-foreground mr-1">{suffix}</span>
      </div>
    </motion.div>
  );
}

// ============================================================
// StatusBadge
// ============================================================
interface StatusBadgeProps {
  status: 'له' | 'علينا' | 'متعادل';
  size?: 'sm' | 'md';
}

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const map = {
    له:       { cls: 'bg-success/15 text-success border border-success/30', icon: <TrendingUp  size={12} />, label: '✅ له علينا' },
    علينا:    { cls: 'bg-destructive/15 text-destructive border border-destructive/30', icon: <TrendingDown size={12} />, label: '🔴 علينا' },
    متعادل:   { cls: 'bg-muted text-muted-foreground border border-border', icon: <Minus size={12} />, label: '⚖️ متعادل' },
  };
  const { cls, icon, label } = map[status];
  const sz = size === 'sm' ? 'text-xs px-2 py-0.5 gap-1' : 'text-sm px-3 py-1 gap-1.5';

  return (
    <span className={`inline-flex items-center rounded-full font-medium ${cls} ${sz}`}>
      {icon}
      {label}
    </span>
  );
}

// ============================================================
// BalanceDisplay
// ============================================================
interface BalanceDisplayProps {
  balance: number;
  showSign?: boolean;
  className?: string;
}

export function BalanceDisplay({ balance, showSign = true, className = '' }: BalanceDisplayProps) {
  const isPositive = balance > 0;
  const isNegative = balance < 0;
  const colorClass = isPositive ? 'text-success' : isNegative ? 'text-destructive' : 'text-muted-foreground';
  const sign = showSign ? (isPositive ? '+' : isNegative ? '-' : '') : '';

  return (
    <span className={`font-mono font-semibold ${colorClass} ${className}`}>
      {sign}{formatCurrency(balance)} ج.م
    </span>
  );
}

// ============================================================
// EmptyState
// ============================================================
export function EmptyState({ icon, title, description, action }: {
  icon: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
      <div className="p-5 rounded-2xl bg-muted text-muted-foreground">
        {icon}
      </div>
      <div>
        <p className="font-semibold text-foreground text-lg">{title}</p>
        {description && <p className="text-muted-foreground text-sm mt-1">{description}</p>}
      </div>
      {action}
    </div>
  );
}
