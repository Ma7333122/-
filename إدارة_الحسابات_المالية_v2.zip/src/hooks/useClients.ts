import { useState, useEffect, useCallback } from 'react';
import { Client } from '@/lib/index';
import { loadClients, saveClients, addClient as storeAddClient,
         deleteClient as storeDeleteClient, addTransaction as storeAddTx,
         deleteTransaction as storeDeleteTx, clientNameExists } from '@/data/index';

export function useClients() {
  const [clients, setClients] = useState<Client[]>([]);

  const refresh = useCallback(() => setClients(loadClients()), []);

  useEffect(() => { refresh(); }, [refresh]);

  const addClient = useCallback((name: string): { ok: boolean; error?: string; client?: Client } => {
    if (!name.trim()) return { ok: false, error: 'الرجاء إدخال اسم العميل' };
    if (clientNameExists(name)) return { ok: false, error: `العميل "${name}" موجود مسبقاً` };
    const client = storeAddClient(name);
    refresh();
    return { ok: true, client };
  }, [refresh]);

  const deleteClient = useCallback((id: string) => {
    storeDeleteClient(id);
    refresh();
  }, [refresh]);

  const addTransaction = useCallback((
    clientId: string,
    tx: Omit<import('@/lib/index').Transaction, 'id'>
  ) => {
    storeAddTx(clientId, tx);
    refresh();
  }, [refresh]);

  const deleteTransaction = useCallback((clientId: string, txId: string) => {
    storeDeleteTx(clientId, txId);
    refresh();
  }, [refresh]);

  const getClient = useCallback((id: string): Client | undefined =>
    clients.find(c => c.id === id), [clients]);

  const importData = useCallback((data: Client[]) => {
    saveClients(data);
    refresh();
  }, [refresh]);

  return { clients, addClient, deleteClient, addTransaction, deleteTransaction, getClient, refresh, importData };
}